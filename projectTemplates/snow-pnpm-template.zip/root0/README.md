\# New Project

> ✨ Bootstrapped with Create Snowpack App (CSA).

\#\# these aree somehow needed if you use workspace
or if you a custom plugin for decorators

 "@babel/plugin-syntax-import-meta": "^7.10.1",
 "@babel/preset-react": "^7.10.1",
 "@babel/preset-typescript": "^7.10.1",
       
required when running tests       

` "babel-preset-react-app": "^9.1.2",`
       
type definitons for jest-dom

`
@types/testing-library__jest-dom
`

the jsx part

 The preserve mode will keep the JSX as part of the output to be further
  consumed by another transform step (e.g. Babel). Additionally the output will have 
  a .jsx file extension. The react mode will emit React.createElement, does not need to go 
  through a JSX transformation before use, and the output will have a .js file extension