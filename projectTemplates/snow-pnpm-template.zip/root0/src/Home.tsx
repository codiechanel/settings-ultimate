import React from 'react'
import { observer } from 'mobx-react-lite'
import globalStore, { GlobalStore } from './GlobalStore'
import { MyButton, PanelInset } from './styledUI'
import { ToastContainer, toast } from 'react-toastify'
import proxymise from 'proxymise'

// import { Cool, StyledButton } from '@codiechanel/lib-demo'

import { css } from 'emotion'
import fetchy from 'src/fetchy'

interface HomeProps {
  store: GlobalStore
}


const Home = observer(({ store }: HomeProps) => {
  const notify = () => toast('Wow so easy !')
  return (
    <PanelInset>
      {/*<StyledButton>jio</StyledButton>*/}
      <div className="bg-blue-900 bg-blue-200">nice {store.counter}</div>

      <MyButton
        onClick={() => {
          store.counter += 1
        }}
      >
        clicker
      </MyButton>
      <MyButton onClick={notify}>toast </MyButton>
      <ToastContainer />
      <MyButton
        onClick={() => {
          console.log('click')
          globalStore.darkMode = !globalStore.darkMode
        }}
      >
        toggle 68
      </MyButton>
    </PanelInset>
  )
})

export default Home
