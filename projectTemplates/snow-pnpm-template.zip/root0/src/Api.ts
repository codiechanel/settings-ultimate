import Color from 'color'

type RGBObj = { r: number; g: number; b: number }
class Api {
  rgbToHex(color: RGBObj) {
    const val = [color.r, color.g, color.b].map((x) => {
      const hex = x.toString(16)
      return hex.length === 1 ? '0' + hex : hex
    })

    return val.join('')
  }
  calcColor(color: { r: number; g: number; b: number }, luminance: number) {
    luminance /= 100

    const hex = this.rgbToHex(color)
    let newHexColor = '\#'
    let colorpair

    for (let i = 0; i < 3; i++) {
      colorpair = parseInt(hex.substr(i * 2, 2), 16)
      colorpair = Math.round(
        Math.min(Math.max(0, colorpair + colorpair * luminance), 255),
      ).toString(16)
      // console.log('colorpair', colorpair)
      /* color pair can be 1 digit ...
       * this code will then 09 */
      newHexColor += ('00' + colorpair).substr(colorpair.length)
      // console.log('newHexColor', '00' + colorpair, newHexColor)
    }
    // console.log('new', newHexColor)

    // return this.hexToRgb(newHexColor)
    return newHexColor
  }
  calcLightShadow(hexColor) {
    let z = Color(hexColor)
    let result = this.calcColor(z.object(), 20)
    return result
  }
  calcDarkShadow(hexColor) {
    let z = Color(hexColor)
    let result = this.calcColor(z.object(), -20)
    return result
  }
}

let api = new Api()

export default api
