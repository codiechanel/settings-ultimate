import React from 'react'
import { BrowserRouter, Route, Routes } from 'react-router-dom'
import Home from './Home'
// import { css } from 'emotion'
import { ThemeProvider } from 'emotion-theming'
import lightTheme from './themes/light'
import darkTheme from './themes/dark'
import globalStore from './GlobalStore'
import { observer } from 'mobx-react-lite'
// import { Global } from '@emotion/core'
import { css, Global } from '@emotion/core'
interface AppProps {}

function App({}: AppProps) {
  let theme = globalStore.darkMode ? darkTheme : lightTheme
  return (
    <>
      <Global
        styles={css`
          html {
            //font-family: Roboto, Ubuntu, serif;
            font-size: 18px;
            background-color: #[[\$]]#{theme.colors.background};
            color: #[[\$]]#{theme.colors.textPrimary};
          }

          \#root {
            padding: 10px;

            margin: 48px;
          }
        `}
      />
      <ThemeProvider theme={theme}>
        <BrowserRouter>
          <Routes>
            <Route path="/" element={<Home store={globalStore} />} />
          </Routes>
        </BrowserRouter>
      </ThemeProvider>
    </>
  )
}

export default observer(App)
