import proxymise from 'proxymise'

class Fetchy {
  res = null
  record = null
  async getSource(url) {
    this.res = await fetch(url)
    console.log('hey')
    return this
  }
  getLinks() {
    // strip links from page
    this.record = this.res.json()
    return this
  }
}

export default proxymise(new Fetchy())
