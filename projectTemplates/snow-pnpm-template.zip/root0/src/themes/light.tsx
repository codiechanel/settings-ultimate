import api from '../Api'

export default {
  colors: {
    background: '\#EEF0F5',
    darkShadow: api.calcDarkShadow('\#EEF0F5'),
    lightShadow: api.calcLightShadow('\#EEF0F5'),
    textPrimary: '\#000000',
  },
}
