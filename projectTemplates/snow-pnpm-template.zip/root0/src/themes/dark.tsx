import api from 'src/Api'

export default {
  colors: {
    background: '\#24242C',
    darkShadow: api.calcDarkShadow('\#24242C'),
    lightShadow: api.calcLightShadow('\#24242C'),
    textPrimary: '\#ffffff',
  },
}
