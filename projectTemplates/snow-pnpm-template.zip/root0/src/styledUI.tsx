import styled from '@emotion/styled'
export const MyButton = styled.div`
  display: inline-block;
  padding: 16px;
  border-radius: 6px;
  //vertical-align: middle;
  line-height: 1;
  background: #[[\$]]#{(props: any) => props.theme.colors.background};
  box-shadow: 3px 3px 5px #[[\$]]#{(props: any) => props.theme.colors.darkShadow},
    -3px -3px 5px #[[\$]]#{(props: any) => props.theme.colors.lightShadow};
`

export const PanelInset = styled.div`
  flex: 1;
  flex-direction: column;
  background: #[[\$]]#{(props: any) => props.theme.colors.background};
  box-shadow: #[[\$]]#{(props: any) => props.theme.colors.darkShadow} 1px 1px 3px inset,
    #[[\$]]#{(props: any) => props.theme.colors.lightShadow} -1px -1px 3px inset;
  border-radius: 24px;
  padding: 20px;
`
