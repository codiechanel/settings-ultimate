import { observable } from 'mobx'

export class GlobalStore {
  @observable
  counter: number

  @observable darkMode = true

  constructor() {
    this.counter = 0
  }
}

let globalStore = new GlobalStore()

export default globalStore
